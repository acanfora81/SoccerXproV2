// server/src/routes/taxes.js
// 📊 API per calcolo fiscale lordo↔netto

const express = require('express');
const router = express.Router();

const {
  calculateSalary,
  calculateGrossFromNet
} = require('../utils/salaryCalculator');

// ➕ Lordo → Netto
router.post('/net-from-gross', async (req, res) => {
  try {
    const { grossSalary, taxRates, opts } = req.body;

    if (!grossSalary || grossSalary <= 0) {
      return res.status(400).json({ success: false, error: 'grossSalary obbligatorio' });
    }

    const result = calculateSalary(grossSalary, taxRates, opts);

    res.json({ success: true, data: result });
  } catch (err) {
    console.error('❌ Errore net-from-gross:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 🔄 Netto → Lordo
router.post('/gross-from-net', async (req, res) => {
  try {
    const { netSalary, taxRates, opts } = req.body;

    if (!netSalary || netSalary <= 0) {
      return res.status(400).json({ success: false, error: 'netSalary obbligatorio' });
    }

    const result = calculateGrossFromNet(netSalary, taxRates, opts);

    res.json({ success: true, data: result });
  } catch (err) {
    console.error('❌ Errore gross-from-net:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
