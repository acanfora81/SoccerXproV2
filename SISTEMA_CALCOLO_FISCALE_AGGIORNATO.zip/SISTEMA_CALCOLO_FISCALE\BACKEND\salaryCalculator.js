// 02_BACKEND/03_Utilità_Calcolo/salaryCalculator.js
// Calcolo lordo↔netto + costo aziendale, logica conforme al foglio Excel

function round2(v) {
  return Math.round((v + Number.EPSILON) * 100) / 100;
}

function progressiveRound(value, step = 0.01) {
  // arrotondamento stile Excel (centesimi ad ogni passaggio)
  return Math.round(value / step) * step;
}

/**
 * Calcolo IRPEF per scaglioni
 */
function calcIrpefByBrackets(imponibile, brackets) {
  let remaining = imponibile;
  let irpef = 0;
    for (const b of brackets) {
    const chunk = Math.max(
      0,
      Math.min(remaining, b.to === Infinity ? remaining : b.to - (b.from ?? 0))
    );
    if (chunk <= 0) continue;
    irpef += chunk * b.rate;
    remaining -= chunk;
    if (remaining <= 0) break;
  }
  return irpef;
}

/**
 * Detrazioni per lavoro dipendente (semplificate ma coerenti con Excel)
 */
function detrazioniLavoroDipendente(reddito) {
  if (reddito <= 15000) return 1880;
  if (reddito <= 28000) {
    return 1910 - 1910 * ((reddito - 15000) / 13000);
  }
  if (reddito <= 50000) {
    return 1910 * ((50000 - reddito) / 22000);
  }
  return 0;
}

/**
 * Calcolo lordo → netto
 */
function calculateSalary(grossSalary, taxRates = {}) {
  const gross = Number(grossSalary);
  if (!isFinite(gross) || gross <= 0) {
    return {
      input: { grossSalary: 0 },
      worker: { inps: 0, ffc: 0, solidarity: 0 },
      taxableIncome: 0,
      irpef: { gross: 0, deductions: 0, net: 0 },
      additionals: 0,
      netSalary: 0,
      employer: { inps: 0, inail: 0, ffc: 0 },
      companyCost: 0
    };
  }

  // === Parametri fissi modello Excel ===
  // Nessun contributo lavoratore
  const inpsWorkerRate = 0;
  const ffcWorkerRate = 0;
  const solidarityWorkerRate = 0;

  // Contributi datore
  const inpsEmployerRate = 29.58 / 100;
  const inailEmployerRate = 7.90 / 100;
  const ffcEmployerRate = 6.25 / 100;

  // IRPEF 2025 (se non arrivano brackets dal DB)
  const brackets = taxRates.irpefBrackets ?? [
    { from: 0, to: 28000, rate: 0.23 },
    { from: 28000, to: 50000, rate: 0.35 },
    { from: 50000, to: Infinity, rate: 0.43 }
  ];

  // === 1) Contributi a carico lavoratore (tutti 0) ===
  let inpsWorker = progressiveRound(gross * inpsWorkerRate);
  let ffcWorker = progressiveRound(gross * ffcWorkerRate);
  let solidarityWorker = progressiveRound(gross * solidarityWorkerRate);

  // === 2) Imponibile IRPEF ===
  let imponibile = progressiveRound(gross - (inpsWorker + ffcWorker + solidarityWorker));

  // === 3) IRPEF ===
  let irpefLorda = progressiveRound(calcIrpefByBrackets(imponibile, brackets));
  let detrazioni = progressiveRound(detrazioniLavoroDipendente(imponibile));
  let irpefNetta = progressiveRound(Math.max(0, irpefLorda - detrazioni));

  // === 4) Addizionali escluse ===
  let addizionali = 0;

  // === 5) Netto ===
  let netSalary = round2(
    gross - (inpsWorker + ffcWorker + solidarityWorker) - irpefNetta - addizionali
  );

  // === 6) Contributi a carico azienda ===
  let inpsEmployer = progressiveRound(gross * inpsEmployerRate);
  let inailEmployer = progressiveRound(gross * inailEmployerRate);
  let ffcEmployer = progressiveRound(gross * ffcEmployerRate);

  const companyCost = round2(gross + inpsEmployer + inailEmployer + ffcEmployer);

  return {
    input: { grossSalary: round2(gross) },
    worker: {
      inps: round2(inpsWorker),
      ffc: round2(ffcWorker),
      solidarity: round2(solidarityWorker)
    },
    taxableIncome: round2(imponibile),
    irpef: {
      gross: round2(irpefLorda),
      deductions: round2(detrazioni),
      net: round2(irpefNetta)
    },
    additionals: round2(addizionali),
    netSalary: round2(netSalary),
    employer: {
      inps: round2(inpsEmployer),
      inail: round2(inailEmployer),
      ffc: round2(ffcEmployer)
    },
    companyCost,
    totalWorkerContributions: round2(inpsWorker + ffcWorker + solidarityWorker),
    totalEmployerContributions: round2(inpsEmployer + inailEmployer + ffcEmployer)
  };
}

/**
 * Netto → Lordo (ricerca binaria)
 */
function calculateGrossFromNet(netTarget, taxRates = {}) {
  if (!isFinite(netTarget) || netTarget <= 0) {
    return { grossSalary: 0, ...calculateSalary(0, taxRates) };
  }

  let low = netTarget;
  let high = netTarget * 3;
  let best = null;

  for (let i = 0; i < 60; i++) {
    const mid = Math.round(((low + high) / 2) * 100) / 100; // arrotonda a centesimo
    const res = calculateSalary(mid, taxRates);
    const diff = res.netSalary - netTarget;

    best = res;
    if (Math.abs(diff) <= 0.01) break;
    if (diff > 0) high = mid;
    else low = mid;
  }

  return best;
}

module.exports = { 
  calculateSalary, 
  calculateGrossFromNet 
};