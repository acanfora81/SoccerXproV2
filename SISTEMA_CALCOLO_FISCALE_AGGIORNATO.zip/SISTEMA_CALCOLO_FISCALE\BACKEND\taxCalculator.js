const { PrismaClient } = require('../../prisma/generated/client');
const prisma = new PrismaClient();

/**
 * Calcolo IRPEF progressiva su imponibile
 * @param {number} taxableIncome - Imponibile (lordo - contributi)
 * @param {number} year - Anno di riferimento
 * @returns {Promise<number>} - IRPEF netta (con detrazioni)
 */
async function calcolaIrpef(taxableIncome, year) {
  try {
    console.log('🔵 Calcolo IRPEF:', { taxableIncome, year });

    // Recupera scaglioni IRPEF
    const brackets = await prisma.tax_irpef_bracket.findMany({
      where: { year },
      orderBy: { min: 'asc' }
    });

    if (!brackets.length) {
      console.log('⚠️ Nessuno scaglione IRPEF trovato per anno:', year);
      return 0;
    }

    console.log('🔵 Scaglioni IRPEF trovati:', brackets);

    // Calcolo IRPEF progressiva
    let irpefLorda = 0;
    for (const bracket of brackets) {
      const max = bracket.max || taxableIncome;
      if (taxableIncome > bracket.min) {
        const incomeInBracket = Math.min(taxableIncome, max) - bracket.min;
        const taxInBracket = incomeInBracket * (bracket.rate / 100);
        irpefLorda += taxInBracket;
        
        console.log('🔵 Scaglione:', {
          min: bracket.min,
          max: bracket.max,
          rate: bracket.rate,
          incomeInBracket,
          taxInBracket
        });
      }
    }

    // Recupera detrazioni
    const config = await prisma.tax_config.findUnique({ 
      where: { year } 
    });

    let detrazioni = 0;
    if (config) {
      // Detrazione fissa da lavoro dipendente
      detrazioni += config.detrazionifixed || 0;
      
      // Eventuale detrazione percentuale su IRPEF
      if (config.detrazionipercentonirpef) {
        detrazioni += irpefLorda * (config.detrazionipercentonirpef / 100);
      }
      
      console.log('🔵 Detrazioni:', {
        detrazioniFisse: config.detrazionifixed,
        detrazioniPercentuali: config.detrazionipercentonirpef,
        totaleDetrazioni: detrazioni
      });
    }

    const irpefNetta = Math.max(irpefLorda - detrazioni, 0);

    console.log('🔵 IRPEF Risultato:', {
      irpefLorda,
      detrazioni,
      irpefNetta
    });

    return irpefNetta;

  } catch (error) {
    console.error('🔴 Errore calcolo IRPEF:', error);
    return 0;
  }
}

/**
 * Calcolo Addizionali Regionali e Comunali
 * @param {number} taxableIncome - Imponibile 
 * @param {number} year - Anno di riferimento
 * @param {string} region - Regione (es. "Lombardia")
 * @param {string} municipality - Comune (es. "Milano")
 * @returns {Promise<number>} - Totale addizionali
 */
async function calcolaAddizionali(taxableIncome, year, region, municipality) {
  try {
    console.log('🔵 Calcolo Addizionali:', { taxableIncome, year, region, municipality });

    let totaleAddizionali = 0;

    // Addizionale Regionale
    const addRegionale = await prisma.tax_regional_additional.findFirst({
      where: { 
        year,
        region: region || 'DEFAULT'
      }
    });

    if (addRegionale) {
      const regionaleImporto = taxableIncome * (addRegionale.rate / 100);
      totaleAddizionali += regionaleImporto;
      console.log('🔵 Addizionale Regionale:', {
        region,
        rate: addRegionale.rate,
        importo: regionaleImporto
      });
    }

    // Addizionale Comunale  
    const addComunale = await prisma.tax_municipal_additional.findFirst({
      where: { 
        year,
        region: region || 'DEFAULT',
        municipality: municipality || 'DEFAULT'
      }
    });

    if (addComunale) {
      const comunaleImporto = taxableIncome * (addComunale.rate / 100);
      totaleAddizionali += comunaleImporto;
      console.log('🔵 Addizionale Comunale:', {
        municipality,
        rate: addComunale.rate,
        importo: comunaleImporto
      });
    }

    console.log('🔵 Addizionali Totali:', totaleAddizionali);
    return totaleAddizionali;

  } catch (error) {
    console.error('🔴 Errore calcolo Addizionali:', error);
    return 0;
  }
}

/**
 * Calcolo completo da lordo a netto (CORRETTO)
 * @param {number} grossSalary - Stipendio lordo
 * @param {Object} taxRates - Aliquote contributive
 * @param {number} year - Anno
 * @param {string} region - Regione
 * @param {string} municipality - Comune
 * @returns {Promise<Object>} - Calcolo completo
 */
async function calcolaStipendioCompleto(grossSalary, taxRates, year, region = null, municipality = null) {
  try {
    console.log('🔵 Calcolo Stipendio Completo:', { grossSalary, taxRates, year, region, municipality });

    // --- STEP 1: Contributi a carico lavoratore ---
    const inpsWorker = (grossSalary * (parseFloat(taxRates.inpsWorker) || 0)) / 100;
    const ffcWorker = (grossSalary * (parseFloat(taxRates.ffcWorker) || 0)) / 100;
    const solidarityWorker = (grossSalary * (parseFloat(taxRates.solidarityWorker) || 0)) / 100;
    
    const totaleContributiWorker = inpsWorker + ffcWorker + solidarityWorker;

    // --- STEP 2: Imponibile fiscale ---
    const taxableIncome = grossSalary - totaleContributiWorker;

    // --- STEP 3: IRPEF progressiva ---
    const irpef = await calcolaIrpef(taxableIncome, year);

    // --- STEP 4: Addizionali ---
    const addizionali = await calcolaAddizionali(taxableIncome, year, region, municipality);

    // --- STEP 5: Netto lavoratore ---
    const netSalary = grossSalary - totaleContributiWorker - irpef - addizionali;

    // --- STEP 6: Contributi a carico datore ---
    const inpsEmployer = (grossSalary * (parseFloat(taxRates.inpsEmployer) || 0)) / 100;
    const inailEmployer = (grossSalary * (parseFloat(taxRates.inailEmployer) || 0)) / 100;
    const ffcEmployer = (grossSalary * (parseFloat(taxRates.ffcEmployer) || 0)) / 100;
    const solidarityEmployer = (grossSalary * (parseFloat(taxRates.solidarityEmployer) || 0)) / 100;
    
    const totaleContributiEmployer = inpsEmployer + inailEmployer + ffcEmployer + solidarityEmployer;

    // --- STEP 7: Costo totale società ---
    const companyCost = grossSalary + totaleContributiEmployer;

    const risultato = {
      // Input
      grossSalary,
      
      // Contributi lavoratore
      inpsWorker,
      ffcWorker,
      solidarityWorker,
      totaleContributiWorker,
      
      // Tasse
      taxableIncome,
      irpef,
      addizionali,
      
      // Risultato lavoratore
      netSalary,
      
      // Contributi datore
      inpsEmployer,
      inailEmployer,
      ffcEmployer,
      solidarityEmployer,
      totaleContributiEmployer,
      
      // Risultato società
      companyCost
    };

    console.log('🔵 Calcolo Completo Risultato:', risultato);
    return risultato;

  } catch (error) {
    console.error('🔴 Errore calcolo stipendio completo:', error);
    throw error;
  }
}

module.exports = { 
  calcolaIrpef, 
  calcolaAddizionali,
  calcolaStipendioCompleto
};


