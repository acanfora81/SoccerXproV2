# 📋 ISTRUZIONI USO - Sistema Calcolo Fiscale

## 🚀 **AVVIO RAPIDO**

### **1. Avvia il Server Backend**
```bash
cd server
npm run dev
```

### **2. Avvia il Frontend**
```bash
cd client
npm run dev
```

### **3. Testa l'Applicazione**
1. Apri http://localhost:5173
2. Vai alla creazione di un nuovo contratto
3. Inserisci la data di inizio contratto
4. Inserisci 33.500€ nel campo netto
5. Verifica che il lordo sia €45.809,52

## 📊 **ENDPOINT API DISPONIBILI**

### **Calcoli Fiscali**
```bash
# Netto → Lordo
POST http://localhost:3001/api/taxes/gross-from-net
{
  "netSalary": 33500,
  "taxRates": {
    "irpefBrackets": [
      { "from": 0, "to": 28000, "rate": 0.23 },
      { "from": 28000, "to": 50000, "rate": 0.35 },
      { "from": 50000, "to": Infinity, "rate": 0.43 }
    ]
  }
}

# Lordo → Netto
POST http://localhost:3001/api/taxes/net-from-gross
{
  "grossSalary": 56565,
  "taxRates": { ... }
}
```

### **Gestione Contratti**
```bash
# Crea contratto
POST http://localhost:3001/api/contracts

# Lista contratti
GET http://localhost:3001/api/contracts

# Aggiorna contratto
PUT http://localhost:3001/api/contracts/:id
```

### **Gestione Aliquote**
```bash
# Carica aliquote stipendio
POST http://localhost:3001/api/taxrates/upload

# Carica aliquote bonus
POST http://localhost:3001/api/bonustaxrates/upload

# Lista aliquote
GET http://localhost:3001/api/taxrates?teamId=1
```

## 🔧 **CONFIGURAZIONE**

### **Parametri Calcolo (salaryCalculator.js)**
```javascript
// Contributi datore (fissi per Excel)
const inpsEmployerRate = 29.58 / 100;  // 29,58%
const inailEmployerRate = 7.90 / 100;  // 7,9%
const ffcEmployerRate = 6.25 / 100;    // 6,25%

// Contributi lavoratore (sempre 0 per Excel)
const inpsWorkerRate = 0;
const ffcWorkerRate = 0;
const solidarityWorkerRate = 0;

// IRPEF 2025
const brackets = [
  { from: 0, to: 28000, rate: 0.23 },
  { from: 28000, to: 50000, rate: 0.35 },
  { from: 50000, to: Infinity, rate: 0.43 }
];
```

### **Formato CSV Aliquote**
```csv
year;type;inps;inail;ffc
2025;PROFESSIONAL;9,19;0,00;1,25
2025;APPRENTICESHIP;5,84;0,00;1,25
2025;AMATEUR;2,00;0,00;0,50
2025;YOUTH;1,50;0,00;0,30
```

## 📝 **FILE PRINCIPALI**

### **Frontend**
- `useUnifiedFiscalCalculation.js` - Hook principale con integrazione API
- `NewContractModal.jsx` - Modale contratti con fix errori
- `italianNumbers.js` - Conversione numeri italiani

### **Backend**
- `salaryCalculator.js` - Logica unica conforme Excel
- `taxes.js` - Endpoint API per calcoli
- `contracts.js` - Controller contratti

### **Database**
- `schema.prisma` - Schema database

## 🐛 **RISOLUZIONE PROBLEMI**

### **Errore "Cannot read properties of undefined"**
- ✅ **Risolto**: Protezioni con optional chaining
- ✅ **Risolto**: Gestione async corretta

### **Pagina bianca**
- ✅ **Risolto**: Fallback sicuri per valori mancanti
- ✅ **Risolto**: Gestione errori migliorata

### **Calcoli non funzionano**
- ✅ **Risolto**: Integrazione API backend
- ✅ **Risolto**: Logica unica conforme Excel

### **Numeri gonfiati**
- ✅ **Risolto**: Arrotondamenti progressivi
- ✅ **Risolto**: Tolleranza centesimale

## 📊 **TEST E VERIFICA**

### **Test Calcoli**
```javascript
// Test con 33.500€ netto
const result = await calculateGrossFromNet(33500, taxRates);
console.log('Lordo:', result.input.grossSalary); // Dovrebbe essere ~45.809,52
console.log('Netto:', result.netSalary); // Dovrebbe essere 33.500,00
```

### **Test Endpoint**
```bash
# Test con cURL
curl -X POST http://localhost:3001/api/taxes/gross-from-net \
  -H "Content-Type: application/json" \
  -d '{"netSalary": 33500, "taxRates": {...}}'
```

## 🎯 **RISULTATI ATTESI**

### **Input: 33.500€ netto**
- **Output lordo**: €45.809,52
- **Contributi datore**: €20.032,51
- **Costo aziendale**: €65.842,03
- **IRPEF netta**: €12.309,52

### **Input: 56.565€ lordo**
- **Output netto**: €42.425,00
- **Contributi datore**: €24.693,88
- **Costo aziendale**: €81.300,88

## 📞 **SUPPORTO**

### **Log da Controllare**
1. **Console browser** (F12) - Errori frontend
2. **Console server** - Errori backend
3. **Network tab** - Chiamate API

### **File di Debug**
- `FIX_ERROR_FRONTEND.md` - Fix errori applicati
- `INTEGRAZIONE_COMPLETATA.md` - Integrazione completata
- `ISTRUZIONI_TEST_CALCOLO.md` - Test calcoli

---
**Creato il**: 21/09/2025  
**Versione**: SoccerXpro V2  
**Sistema**: Istruzioni Uso Sistema Calcolo Fiscale
